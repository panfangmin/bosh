/* This file is auto generated, version 53 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#53 SMP Tue Jun 10 00:35:11 UTC 2014"
#define LINUX_COMPILE_BY "ubuntu"
#define LINUX_COMPILE_HOST "ip-10-0-0-162"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
